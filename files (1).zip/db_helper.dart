import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/caisse_operation.dart';
import '../models/fiche_controle.dart';

/// Gère la base de données SQLite locale de l'application.
/// Deux tables : operations (Livre de caisse) et fiches_controle (Fiche de contrôle).
class DBHelper {
  static final DBHelper instance = DBHelper._internal();
  factory DBHelper() => instance;
  DBHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'caisse_isitek.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE operations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        annee TEXT NOT NULL,
        mois TEXT NOT NULL,
        semaine TEXT NOT NULL,
        periodeDu TEXT NOT NULL,
        periodeAu TEXT NOT NULL,
        date TEXT NOT NULL,
        numPiece TEXT,
        nomPrenoms TEXT,
        detailOperation TEXT,
        entree REAL NOT NULL DEFAULT 0,
        sortie REAL NOT NULL DEFAULT 0,
        solde REAL NOT NULL DEFAULT 0,
        signataireOk INTEGER NOT NULL DEFAULT 0,
        estSoldeOuverture INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE fiches_controle (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        semaine TEXT NOT NULL,
        periodeDu TEXT NOT NULL,
        periodeAu TEXT NOT NULL,
        soldeTheorique REAL NOT NULL DEFAULT 0,
        soldeReel REAL NOT NULL DEFAULT 0,
        ecartAvt REAL NOT NULL DEFAULT 0,
        observations TEXT,
        ecartApt REAL NOT NULL DEFAULT 0,
        repOperationsNom TEXT,
        comptableNom TEXT,
        directionNom TEXT
      )
    ''');

    await db.execute('CREATE INDEX idx_op_annee ON operations(annee)');
    await db.execute('CREATE INDEX idx_op_mois ON operations(mois)');
    await db.execute('CREATE INDEX idx_op_semaine ON operations(semaine)');
    await db.execute('CREATE INDEX idx_op_solde ON operations(solde)');
    await db.execute('CREATE INDEX idx_op_nom ON operations(nomPrenoms)');
    await db.execute('CREATE INDEX idx_fc_semaine ON fiches_controle(semaine)');
  }

  // ----------------- CRUD : OPERATIONS (Livre de caisse) -----------------

  Future<int> insertOperation(CaisseOperation op) async {
    final db = await database;
    return await db.insert('operations', op.toMap()..remove('id'));
  }

  Future<int> updateOperation(CaisseOperation op) async {
    final db = await database;
    return await db.update(
      'operations',
      op.toMap(),
      where: 'id = ?',
      whereArgs: [op.id],
    );
  }

  Future<int> deleteOperation(int id) async {
    final db = await database;
    return await db.delete('operations', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<CaisseOperation>> getAllOperations() async {
    final db = await database;
    final maps = await db.query('operations', orderBy: 'date ASC, id ASC');
    return maps.map((m) => CaisseOperation.fromMap(m)).toList();
  }

  /// Récupère les opérations d'une semaine précise (par période exacte).
  Future<List<CaisseOperation>> getOperationsBySemaine({
    required String annee,
    required String mois,
    required String semaine,
  }) async {
    final db = await database;
    final maps = await db.query(
      'operations',
      where: 'annee = ? AND mois = ? AND semaine = ?',
      whereArgs: [annee, mois, semaine],
      orderBy: 'estSoldeOuverture DESC, date ASC, id ASC',
    );
    return maps.map((m) => CaisseOperation.fromMap(m)).toList();
  }

  /// Recalcule en une seule transaction les soldes de toutes les opérations
  /// non-ouverture d'une semaine, à partir du solde d'ouverture fourni.
  /// Utiliser une transaction garantit qu'aucune opération n'est laissée
  /// avec un solde incohérent en cas d'interruption (crash, fermeture app).
  Future<void> recalculerSoldesEnCascade({
    required String annee,
    required String mois,
    required String semaine,
    required double montantOuverture,
  }) async {
    final db = await database;
    await db.transaction((txn) async {
      final maps = await txn.query(
        'operations',
        where: 'annee = ? AND mois = ? AND semaine = ?',
        whereArgs: [annee, mois, semaine],
        orderBy: 'estSoldeOuverture DESC, date ASC, id ASC',
      );
      final ops = maps.map((m) => CaisseOperation.fromMap(m)).toList();
      double solde = montantOuverture;
      for (final op in ops) {
        if (op.estSoldeOuverture) continue;
        solde = solde + op.entree - op.sortie;
        if (op.solde != solde) {
          await txn.update(
            'operations',
            op.copyWith(solde: solde).toMap(),
            where: 'id = ?',
            whereArgs: [op.id],
          );
        }
      }
    });
  }

  /// Remplace la ligne d'ouverture de solde d'une semaine (suppression de
  /// l'ancienne + insertion de la nouvelle) de façon atomique, puis recalcule
  /// les soldes en cascade — le tout dans une seule transaction pour éviter
  /// qu'une semaine se retrouve temporairement sans ligne d'ouverture.
  Future<void> definirSoldeOuverture({
    required String annee,
    required String mois,
    required String semaine,
    required DateTime periodeDu,
    required DateTime periodeAu,
    required double montant,
  }) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete(
        'operations',
        where: 'annee = ? AND mois = ? AND semaine = ? AND estSoldeOuverture = 1',
        whereArgs: [annee, mois, semaine],
      );
      final ouverture = CaisseOperation(
        annee: annee,
        mois: mois,
        semaine: semaine,
        periodeDu: periodeDu,
        periodeAu: periodeAu,
        date: periodeDu,
        numPiece: '',
        nomPrenoms: '',
        detailOperation: 'Montant en caisse en début de semaine',
        entree: 0,
        sortie: 0,
        solde: montant,
        estSoldeOuverture: true,
      );
      await txn.insert('operations', ouverture.toMap()..remove('id'));

      final maps = await txn.query(
        'operations',
        where: 'annee = ? AND mois = ? AND semaine = ?',
        whereArgs: [annee, mois, semaine],
        orderBy: 'estSoldeOuverture DESC, date ASC, id ASC',
      );
      final ops = maps.map((m) => CaisseOperation.fromMap(m)).toList();
      double solde = montant;
      for (final op in ops) {
        if (op.estSoldeOuverture) continue;
        solde = solde + op.entree - op.sortie;
        if (op.solde != solde) {
          await txn.update(
            'operations',
            op.copyWith(solde: solde).toMap(),
            where: 'id = ?',
            whereArgs: [op.id],
          );
        }
      }
    });
  }

  /// Vérifie si une semaine (année/mois/n° semaine) existe déjà, pour éviter
  /// les doublons lors de la création d'une nouvelle semaine.
  Future<bool> semaineExiste({
    required String annee,
    required String mois,
    required String semaine,
  }) async {
    final db = await database;
    final result = await db.query(
      'operations',
      columns: ['id'],
      where: 'annee = ? AND mois = ? AND semaine = ?',
      whereArgs: [annee, mois, semaine],
      limit: 1,
    );
    return result.isNotEmpty;
  }

  Future<List<CaisseOperation>> getOperationsByAnnee(String annee) async {
    final db = await database;
    final maps = await db.query(
      'operations',
      where: 'annee = ?',
      whereArgs: [annee],
      orderBy: 'date ASC, id ASC',
    );
    return maps.map((m) => CaisseOperation.fromMap(m)).toList();
  }

  /// Liste distincte des années présentes dans la base.
  Future<List<String>> getAnneesDisponibles() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT DISTINCT annee FROM operations ORDER BY annee DESC',
    );
    return result.map((r) => r['annee'] as String).toList();
  }

  /// Liste distincte (année, mois, semaine, periodeDu, periodeAu) pour navigation.
  Future<List<Map<String, dynamic>>> getSemainesDisponibles({String? annee}) async {
    final db = await database;
    final where = annee != null ? 'WHERE annee = ?' : '';
    final args = annee != null ? [annee] : <dynamic>[];
    final result = await db.rawQuery(
      'SELECT DISTINCT annee, mois, semaine, periodeDu, periodeAu FROM operations $where ORDER BY periodeDu DESC',
      args,
    );
    return result;
  }

  /// Recherche multicritère puissante : permet de taper un solde, un nom,
  /// un numéro de pièce, une année... et de retrouver la ou les lignes complètes.
  Future<List<CaisseOperation>> rechercherOperations({
    String? texte, // recherche libre : nom, détail, n° pièce
    double? solde, // recherche exacte ou approchée sur le solde
    String? annee,
    String? mois,
    String? semaine,
  }) async {
    final db = await database;
    final List<String> conditions = [];
    final List<dynamic> args = [];

    if (texte != null && texte.trim().isNotEmpty) {
      conditions.add(
          '(nomPrenoms LIKE ? OR detailOperation LIKE ? OR numPiece LIKE ?)');
      final like = '%${texte.trim()}%';
      args.addAll([like, like, like]);
    }
    if (solde != null) {
      // Tolérance proportionnelle au montant recherché (0.5 FCFA minimum,
      // 0.5% du montant sinon) pour permettre les arrondis même sur de
      // gros montants, où une tolérance fixe de 0.5 FCFA serait inutile.
      final tolerance = solde.abs() * 0.005 < 0.5 ? 0.5 : solde.abs() * 0.005;
      conditions.add('ABS(solde - ?) < ?');
      args.add(solde);
      args.add(tolerance);
    }
    if (annee != null && annee.isNotEmpty) {
      conditions.add('annee = ?');
      args.add(annee);
    }
    if (mois != null && mois.isNotEmpty) {
      conditions.add('mois = ?');
      args.add(mois);
    }
    if (semaine != null && semaine.isNotEmpty) {
      conditions.add('semaine = ?');
      args.add(semaine);
    }

    final whereClause = conditions.isNotEmpty ? conditions.join(' AND ') : null;

    final maps = await db.query(
      'operations',
      where: whereClause,
      whereArgs: args.isNotEmpty ? args : null,
      orderBy: 'date DESC, id DESC',
    );
    return maps.map((m) => CaisseOperation.fromMap(m)).toList();
  }

  // ----------------- CRUD : FICHES DE CONTROLE -----------------

  Future<int> insertFiche(FicheControle fiche) async {
    final db = await database;
    return await db.insert('fiches_controle', fiche.toMap()..remove('id'));
  }

  Future<int> updateFiche(FicheControle fiche) async {
    final db = await database;
    return await db.update(
      'fiches_controle',
      fiche.toMap(),
      where: 'id = ?',
      whereArgs: [fiche.id],
    );
  }

  Future<int> deleteFiche(int id) async {
    final db = await database;
    return await db.delete('fiches_controle', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<FicheControle>> getAllFiches() async {
    final db = await database;
    final maps = await db.query('fiches_controle', orderBy: 'periodeDu DESC');
    return maps.map((m) => FicheControle.fromMap(m)).toList();
  }

  Future<FicheControle?> getFicheBySemaine(String semaine, DateTime periodeDu) async {
    final db = await database;
    final maps = await db.query(
      'fiches_controle',
      where: 'semaine = ? AND periodeDu = ?',
      whereArgs: [semaine, periodeDu.toIso8601String()],
    );
    if (maps.isEmpty) return null;
    return FicheControle.fromMap(maps.first);
  }

  Future<List<FicheControle>> rechercherFiches({
    String? semaine,
    double? soldeTheorique,
    double? soldeReel,
  }) async {
    final db = await database;
    final List<String> conditions = [];
    final List<dynamic> args = [];

    if (semaine != null && semaine.isNotEmpty) {
      conditions.add('semaine = ?');
      args.add(semaine);
    }
    if (soldeTheorique != null) {
      final tolerance =
          soldeTheorique.abs() * 0.005 < 0.5 ? 0.5 : soldeTheorique.abs() * 0.005;
      conditions.add('ABS(soldeTheorique - ?) < ?');
      args.add(soldeTheorique);
      args.add(tolerance);
    }
    if (soldeReel != null) {
      final tolerance = soldeReel.abs() * 0.005 < 0.5 ? 0.5 : soldeReel.abs() * 0.005;
      conditions.add('ABS(soldeReel - ?) < ?');
      args.add(soldeReel);
      args.add(tolerance);
    }

    final whereClause = conditions.isNotEmpty ? conditions.join(' AND ') : null;

    final maps = await db.query(
      'fiches_controle',
      where: whereClause,
      whereArgs: args.isNotEmpty ? args : null,
      orderBy: 'periodeDu DESC',
    );
    return maps.map((m) => FicheControle.fromMap(m)).toList();
  }

  /// Calcule le solde de caisse courant (dernier solde enregistré, toutes périodes confondues)
  Future<double> getDernierSolde() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT solde FROM operations ORDER BY date DESC, id DESC LIMIT 1',
    );
    if (result.isEmpty) return 0.0;
    return (result.first['solde'] as num).toDouble();
  }
}
