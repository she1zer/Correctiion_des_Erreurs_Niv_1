import 'package:intl/intl.dart';

/// Fonctions utilitaires de formatage utilisées partout dans l'application.
class Formatters {
  static final NumberFormat _montant = NumberFormat('#,##0', 'fr_FR');
  static final DateFormat _dateCourte = DateFormat('dd/MM/yyyy');
  static final DateFormat _dateLongue = DateFormat('dd MMMM yyyy', 'fr_FR');

  /// Formate un montant avec séparateur de milliers, ex: 12 500
  static String montant(double value) {
    if (value == 0) return '0';
    final formatted = _montant.format(value.abs());
    return value < 0 ? '-$formatted' : formatted;
  }

  /// Formate un montant avec le suffixe FCFA
  static String montantFcfa(double value) {
    return '${montant(value)} FCFA';
  }

  static String dateCourte(DateTime date) => _dateCourte.format(date);

  static String dateLongue(DateTime date) => _dateLongue.format(date);

  /// Liste des mois en français, pour les listes déroulantes
  static const List<String> moisFrancais = [
    'Janvier',
    'Février',
    'Mars',
    'Avril',
    'Mai',
    'Juin',
    'Juillet',
    'Août',
    'Septembre',
    'Octobre',
    'Novembre',
    'Décembre',
  ];

  /// Parse un texte de montant saisi par l'utilisateur (gère espaces normaux
  /// et insécables comme séparateurs de milliers, virgule ou point décimal,
  /// et le format mixte "1.234,56"). Retourne null si le texte n'est pas un
  /// nombre valide, pour permettre à l'appelant de distinguer "0" de "invalide".
  static double? parseMontantOrNull(String text) {
    var s = text.trim();
    if (s.isEmpty) return null;
    // Supprime les espaces normaux et insécables utilisés comme séparateurs de milliers
    s = s.replaceAll(RegExp(r'[\s\u00A0\u202F]'), '');
    if (s.contains(',') && s.contains('.')) {
      // Format mixte "1.234,56" -> le point est un séparateur de milliers
      s = s.replaceAll('.', '').replaceAll(',', '.');
    } else {
      s = s.replaceAll(',', '.');
    }
    return double.tryParse(s);
  }

  /// Version rétrocompatible de [parseMontantOrNull] qui renvoie 0.0 quand
  /// le texte est vide ou invalide. À utiliser seulement quand 0 est une
  /// valeur par défaut acceptable ; sinon préférer [parseMontantOrNull] et
  /// afficher une erreur explicite à l'utilisateur.
  static double parseMontant(String text) {
    return parseMontantOrNull(text) ?? 0.0;
  }
}
